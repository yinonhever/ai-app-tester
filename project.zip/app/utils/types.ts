import type { Scan as ScanData } from "~~/shared/types";

export interface Scan extends ScanData {
  _id: string;
  createdAt: string;
  updatedAt: string;
}
